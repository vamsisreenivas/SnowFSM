import {Component, EventEmitter, OnInit, Output} from '@angular/core';
import {OpportunityService} from '../core/_api/opportunity.service';
import {Router} from '@angular/router';
import {GspDialogsComponent} from '../gsp-dialogs/gsp-dialogs.component';
import { HttpClient } from '@angular/common/http';
import { InteractionService } from '../interaction.service';

@Component({
  selector: 'app-gsp-opportunities',
  templateUrl: './gsp-opportunities.component.html',
  styleUrls: ['./gsp-opportunities.component.scss']
})
export class GspOpportunitiesComponent implements OnInit {

  constructor(private opportunityApi: OpportunityService , private route: Router ,private http:HttpClient, private http1:HttpClient, private _interactionService: InteractionService) {}
  
  filterArr: any;
  idCount = 0 ;
  users:any;
  filterUsers:any;
  acounts:any;
  searchTerm: string;

  // private _searchTerm: string;

  // get searchTerm(): string{
  //   return this._searchTerm;
  // }
  // set searchTerm(value: string){
  //   this._searchTerm=value;
  //   this.filterUsers = this.filteredUsers(value);
  // }

  // filteredUsers(searchString:string){
  //   return this.users.filter(user=> user.account.display_value.toString().toLowerCase().indexOf(searchString.toLowerCase()) !== -1);

  // }
  changeText: boolean = false;
  ActiveFilter() {
    this.changeText = true;
  }
  
  ngOnInit() {
    
    this.http.get<any>('/api/now/table/sn_customerservice_case?sysparm_query=contact%3D24e0cd81070c1010928bfd1e7c1ed0b7&sysparm_display_value=true&sysparm_fields=account,number,u_billable,priority,opened_at,u_service_category,u_approximate_service_cost,asset').subscribe( res => {


      // let's take the response, parse the dates and store it in a users array
      this.users = res.result.map( user => {
       
        return user;
  
      // a quick and dirty sort...
      });
      this.filterUsers = this.users;
    });
    
    // this.users.forEach(users => {
    //   users['id'] = this.idCount + 1;
    //   this.idCount++;
    // });
  }
 
  // sampleObj = [
  //   {
  //     'opportunityName' : 'Boxeo',
  //     'opportunityClient' : 'CS0000706',
  //     'flag1' : 'billable',
  //     'alerts' :
  //     [{
  //         'title'  : 'Critical'
  //     },
  //     {
  //       'title'  : 'Warning'
  //     }],
  //     'date' : '28-06-2016',
  //     'type' : 'BreakFix',
  //     'cost' : 'P10000711'
  //   },
  //   {
  //     'opportunityName' : 'Toshiba',
  //     'opportunityClient' : 'CS0000707',
  //     'flag1' : 'investment',
  //     'alerts' :
  //     [{
  //         'title'  : 'Renewal'
  //     },
  //     {
  //       'title'  : 'Warning'
  //     }],
  //     'date' : '28-06-2016',
  //     'type' : 'BreakFix',
  //     'cost' : 'P10000711'
  //   },
  //   {
  //     'opportunityName' : 'Google',
  //     'opportunityClient' : 'CS0000708',
  //     'flag1' : 'non-billable',
  //     'alerts' :
  //     [{
  //         'title'  : 'Renewal'
  //     },
  //     {
  //       'title'  : 'Warning'
  //     }],
  //     'date' : '28-06-2016',
  //     'type' : 'BreakFix',
  //     'cost' : 'P10000711'
  //   },
  //   {
  //     'opportunityName' : 'Cloud',
  //     'opportunityClient' : 'CS0000709',
  //     'flag1' : 'billable',
  //     'alerts' :
  //     [{
  //         'title'  : 'Renewal'
  //     },
  //     {
  //       'title'  : 'Warning'
  //     }],
  //     'date' : '28-06-2016',
  //     'type' : 'Clean&Calibrate',
  //     'cost' : 'P10000711'
  //   },
  //   {
  //     'opportunityName' : 'Mythri',
  //     'opportunityClient' : 'CS0000710',
  //     'flag1' : 'non-billable',
  //     'alerts' :
  //     [
  //     {
  //       'title'  : 'Warning'
  //     }],
  //     'date' : '28-06-2016',
  //     'type' : 'Clean&Calibrate',
  //     'cost' : 'P10000711'
  //   },
  //   {
  //     'opportunityName' : 'Kaola',
  //     'opportunityClient' : 'CS0000711',    
  //       'flag1' : 'billable',
  //     'alerts' :
  //     [
  //     {
  //       'title'  : 'Warning'
  //     }],
  //     'date' : '28-06-2016',
  //     'type' : 'Clean&Calibrate',
  //     'cost' : 'P10000711'
  //   },
  //   {
  //     'opportunityName' : 'Kotak',
  //     'opportunityClient' : 'CS0000712',
  //     'flag1' : 'non-billable',
  //     'alerts' :
  //     [{
  //         'title'  : 'Renewal'
  //     },
  //     {
  //       'title'  : 'Warning'
  //     }],
  //     'date' : '28-06-2016',
  //     'type' : 'Clean&Calibrate',
  //     'cost' : 'P10000711'
  //   },
  //   {
  //     'opportunityName' : 'Corporation',
  //     'opportunityClient' : 'CS0000713',
  //     'flag1' : 'investment',
  //     'alerts' :
  //     [{
  //         'title'  : 'Renewal'
  //     },
  //     {
  //       'title'  : 'Warning'
  //     }],
  //     'date' : '28-06-2016',
  //     'type' : 'Clean&Calibrate',
  //     'cost' : 'P10000711'
  //   },
  //   {
  //     'opportunityName' : 'Mizuce',
  //     'opportunityClient' : 'CS0000714',
  //     'flag1' : 'investment',
  //     'alerts' :
  //     [{
  //         'title'  : 'Renewal'
  //     },
  //     {
  //       'title'  : 'Warning'
  //     }],
  //     'date' : '28-06-2016',
  //     'type' : 'BreakFix',
  //     'cost' : 'P10000711'
  //   },
  //   {
  //     'opportunityName' : 'Loop',
  //     'opportunityClient' : 'CS0000715',
  //     'flag1' : 'investment',
  //     'alerts' :
  //     [{
  //         'title'  : 'Renewal'
  //     },
  //     {
  //       'title'  : 'Warning'
  //     }],
  //     'date' : '28-06-2016',
  //     'type' : 'BreakFix',
  //     'cost' : 'P10000711'
  //   },
  //   {
  //     'opportunityName' : 'Nissan',
  //     'opportunityClient' : 'CS0000716',
  //     'flag1' : 'investment',
  //     'alerts' :
  //     [{
  //         'title'  : 'Renewal'
  //     },
  //     {
  //       'title'  : 'Warning'
  //     }],
  //     'date' : '28-06-2016',
  //     'type' : 'Preventive Maintenance',
  //     'cost' : 'P10000711'
  //   },
  //   {
  //     'opportunityName' : 'UHG',
  //     'opportunityClient' : 'CS0000717',
  //     'flag1' : 'non-billable',
  //     'alerts' :
  //     [{
  //         'title'  : 'Renewal'
  //     },
  //     {
  //       'title'  : 'Warning'
  //     }],
  //     'date' : '28-06-2016',
  //     'type' : 'Preventive Maintenance',
  //     'cost' : 'P10000711'
  //   },
  //   {
  //     'opportunityName' : 'Oneweb',
  //     'opportunityClient' : 'CS0000718',
  //     'flag1' : 'billable',
  //     'alerts' :
  //     [{
  //         'title'  : 'Renewal'
  //     },
  //     {
  //       'title'  : 'Warning'
  //     }],
  //     'date' : '28-06-2016',
  //     'type' : 'Preventive Maintenance',
  //     'cost' : 'P10000711'
  //   },
  //   {
  //     'opportunityName' : 'Snow',
  //     'opportunityClient' : 'CS0000719',
  //     'flag1' : 'billable',
  //     'alerts' :
  //     [{
  //         'title'  : 'Renewal'
  //     },
  //     {
  //       'title'  : 'Warning'
  //     }],
  //     'date' : '28-06-2016',
  //     'type' : 'BreakFix',
  //     'cost' : 'P10000711'
  //   }

  // ];

  
  //`${opportunityId}`
  refreshingModalBeforeOpening(){
    console.log("Escaping error");
  }

  goToDetailView(opportunityId: string, asset: string) {
    // this._interactionService.sendNumber(opportunityId);
    // this._interactionService.sendAst(asset);
    //this.route.navigate(['/number' + opportunityId]).then(r => console.log(r));
    this.route.navigate(['/CaseDetail'], {queryParams:{number:opportunityId}}).then(r => console.log(r));
  }

}
