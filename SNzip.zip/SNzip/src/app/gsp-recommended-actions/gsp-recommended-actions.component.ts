import { Component, OnInit } from '@angular/core';
import {NotifierService} from 'angular-notifier';


@Component({
  selector: 'app-gsp-recommended-actions',
  templateUrl: './gsp-recommended-actions.component.html',
  styleUrls: ['./gsp-recommended-actions.component.scss'],
})
export class GspRecommendedActionsComponent implements OnInit {

  sampleObj = [
    {
    id : 1,
      state : 'block',
    actionTitle : 'KAOLA - P10000711',
    actionDesc  : 'Workorder Task due date -> 28-06-2012',
    date : '28-06-2016',
    cost : ' ',
  },
  {
    id : 2,
    actionTitle : 'Boxeo - P10000706',
    state : 'block',
    actionDesc  : 'Workorder Task due date -> 28-06-2012',
    date : '28-07-2017',
    cost : ' ',
  },
  {
    id : 3,
    actionTitle : 'Toshiba - P10000707',
    state : 'block',
    actionDesc  : 'Workorder Task due date -> 28-06-2012',
    date : '08-06-2016',
    cost : ' ',
  },
  {
    id : 4,
    actionTitle : 'Toshiba - P10000707',
    state : 'block',
    actionDesc  : 'Workorder Task due date -> 28-06-2012',
    date : '20-06-2016',
    cost : ' ',
  },
  {
    id : 5,
    actionTitle : 'Toshiba - P10000707',
    state : 'block',
    actionDesc  : 'Workorder Task due date -> 28-06-2012',
    date : '28-06-2016',
    cost : ' ',
  },


];

  constructor(private notifier: NotifierService) { }

  ngOnInit() {
  }


  clearRecommendedActionList(index , Obj ) {
    this.sampleObj.splice(index, 1);
    this.notifier.notify('default', 'Action ' + `${Obj.actionTitle}` + ' is deleted !');
  }

}
