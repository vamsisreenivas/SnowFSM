import { Injectable } from '@angular/core';
import { Subject, BehaviorSubject } from 'rxjs';
import { HttpClient } from '@angular/common/http';

@Injectable()
// {
//   providedIn: 'root'
// }
export class InteractionService {

  private _userNumber = new BehaviorSubject<any>('');
  private _assetNumber = new BehaviorSubject<any>('');
  userNumber$ = this._userNumber.asObservable();
  assetNumber$ = this._assetNumber.asObservable();

  caseNumber:string;
  ast:any;
  assetNumber:string;

  constructor(private http:HttpClient) { }

  sendNumber(number1:any){
    console.log(number1);
    this._userNumber.next(number1);
  }

  sendAst(astNumber:any){
    console.log(astNumber);
    this._assetNumber.next(astNumber);
  }

  // sendAsset() {
  //   console.log("Pre-Assset "+this.assetNumber);
  //   return this.assetNumber;
  // }
}
