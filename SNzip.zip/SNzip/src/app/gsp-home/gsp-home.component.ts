import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-gsp-home',
  templateUrl: './gsp-home.component.html',
  styleUrls: ['./gsp-home.component.scss']
})
export class GspHomeComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
