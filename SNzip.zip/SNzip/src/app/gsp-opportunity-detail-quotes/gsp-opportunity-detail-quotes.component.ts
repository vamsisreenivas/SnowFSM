import { Component, OnInit } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import { InteractionService } from '../interaction.service';


@Component({
  selector: 'app-gsp-opportunity-detail-quotes',
  templateUrl: './gsp-opportunity-detail-quotes.component.html',
  styleUrls: ['./gsp-opportunity-detail-quotes.component.scss']
})
export class GspOpportunityDetailQuotesComponent implements OnInit {

  constructor(private http: HttpClient, private _interactionService: InteractionService) { }

  ast:any;
  astNumber:any;

  ngOnInit() {
    this._interactionService.assetNumber$.subscribe( res => this.ast = res);
  //   this._interactionService.assetNumber$.subscribe( number3 => this.astNumber = number3);
  //   //this.astNumber = this._interactionService.sendAsset();
  //   console.log("astNumber "+this.astNumber);
  //   this.http.get<any>('/api/now/table/alm_asset?sysparm_query=display_name%3D'+this.astNumber+'&sysparm_display_value=true').subscribe( (res) => {
  //     this.ast = res.result[0];
  //     console.log("Asset: "+this.ast);
  //     return this.ast;
  //   });
  }
  

}
