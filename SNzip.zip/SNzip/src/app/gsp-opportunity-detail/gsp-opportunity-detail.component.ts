import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { InteractionService } from '../interaction.service';

@Component({
  selector: 'app-gsp-opportunity-detail',
  templateUrl: './gsp-opportunity-detail.component.html',
  styleUrls: ['./gsp-opportunity-detail.component.scss']
})
export class GspOpportunityDetailComponent implements OnInit {

  opportunityTab: any;
  quotesTab: any;
  workorderTab:any;
  // customer:any;
  constructor(private route: ActivatedRoute, private http: HttpClient, private _interactionService: InteractionService) { }
  caseNumber:string;
  case:any;
  asset:any;
  astNumber:string;

  ngOnInit() {
    this.route.queryParams.subscribe((params) => {
      let id = params['number'];
      this.caseNumber = id;
      console.log("CaseNumber: "+this.caseNumber);
    });

    this.http.get<any>('/api/now/table/sn_customerservice_case?sysparm_query=number%3D'+this.caseNumber+'&sysparm_display_value=true').subscribe( (res) => {
      this.case = res.result[0];
      
      console.log("Asset "+this.case.asset.display_value);
      this.astNumber = this.case.asset.display_value;
      this._interactionService.sendNumber(this.case);
      
      this.http.get<any>('/api/now/table/alm_asset?sysparm_query=display_name%3D'+this.astNumber+'&sysparm_display_value=true').subscribe( (res) => {
        this.asset = res.result[0];
        this._interactionService.sendAst(this.asset);
      });
      
    });

    
  }

}
